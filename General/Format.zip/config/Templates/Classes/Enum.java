<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @subAuthor Name <e-mail>
 * @author ${user}
 */
public enum ${name} {

}
